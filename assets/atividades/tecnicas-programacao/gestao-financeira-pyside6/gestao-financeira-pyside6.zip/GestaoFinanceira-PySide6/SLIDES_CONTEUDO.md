# Conteudo sugerido para os slides

## Slide 1 - Sistema de Gestao Financeira com PySide6

TPII, integrantes, DSM - 3o semestre, Fatec Indaiatuba.

## Slide 2 - PySide6 e Qt 6

Binding oficial para Python, interface multiplataforma, widgets e modelo de sinais e slots.

## Slide 3 - Vantagens e limitacoes

Comparar visual profissional, variedade de componentes e multiplataforma com tamanho da dependencia e curva de aprendizado.

## Slide 4 - Funcionalidades

CRUD de receitas e despesas, resumo, busca, filtros, SQLite e exportacao CSV.

## Slide 5 - Arquitetura em camadas

Interface PySide6 > servico e validacoes > repositorio > SQLite.

## Slide 6 - Demonstracao no PyCharm

Executar, cadastrar, editar, filtrar, exportar e excluir.

## Slide 7 - Trechos importantes

Sinal conectado ao evento, dinheiro em centavos e SQL parametrizado.

## Slide 8 - Testes e resultados

CRUD, resumo, filtro e validacao testados com banco temporario.

## Slide 9 - Conclusao

PySide6 oferece uma base completa para desktop e a arquitetura facilita manutencao e testes.

