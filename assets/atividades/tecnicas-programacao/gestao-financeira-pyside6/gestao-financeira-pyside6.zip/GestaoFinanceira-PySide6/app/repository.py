"""Acesso aos lancamentos financeiros armazenados no SQLite."""
from __future__ import annotations
from datetime import date

from app.database import Database
from app.models import FinancialSummary, Transaction, TransactionFilter, TransactionType


class TransactionRepository:
    def __init__(self, database: Database):
        self.database = database

    @staticmethod
    def _from_row(row) -> Transaction:
        return Transaction(
            id=row["id"],
            description=row["description"],
            amount_cents=row["amount_cents"],
            transaction_type=TransactionType(row["transaction_type"]),
            category=row["category"],
            transaction_date=date.fromisoformat(row["transaction_date"]),
            notes=row["notes"],
        )

    def add(self, transaction: Transaction) -> int:
        with self.database.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO transactions
                (description, amount_cents, transaction_type, category,
                 transaction_date, notes)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (transaction.description, transaction.amount_cents,
                 transaction.transaction_type.value, transaction.category,
                 transaction.transaction_date.isoformat(), transaction.notes),
            )
            return int(cursor.lastrowid)

    def update(self, transaction: Transaction) -> None:
        with self.database.connect() as connection:
            cursor = connection.execute(
                """UPDATE transactions SET description = ?, amount_cents = ?,
                transaction_type = ?, category = ?, transaction_date = ?, notes = ?,
                updated_at = CURRENT_TIMESTAMP WHERE id = ?""",
                (transaction.description, transaction.amount_cents,
                 transaction.transaction_type.value, transaction.category,
                 transaction.transaction_date.isoformat(), transaction.notes,
                 transaction.id),
            )
            if cursor.rowcount == 0:
                raise LookupError("Lancamento nao encontrado.")

    def delete(self, transaction_id: int) -> None:
        with self.database.connect() as connection:
            cursor = connection.execute(
                "DELETE FROM transactions WHERE id = ?", (transaction_id,)
            )
            if cursor.rowcount == 0:
                raise LookupError("Lancamento nao encontrado.")

    def get(self, transaction_id: int) -> Transaction | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM transactions WHERE id = ?", (transaction_id,)
            ).fetchone()
        return self._from_row(row) if row else None

    def list(self, filters: TransactionFilter) -> list[Transaction]:
        clauses, parameters = [], []
        if filters.text:
            clauses.append("(description LIKE ? OR notes LIKE ?)")
            term = f"%{filters.text}%"
            parameters.extend([term, term])
        if filters.transaction_type:
            clauses.append("transaction_type = ?")
            parameters.append(filters.transaction_type.value)
        if filters.category:
            clauses.append("category = ?")
            parameters.append(filters.category)
        if filters.start_date:
            clauses.append("transaction_date >= ?")
            parameters.append(filters.start_date.isoformat())
        if filters.end_date:
            clauses.append("transaction_date <= ?")
            parameters.append(filters.end_date.isoformat())
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with self.database.connect() as connection:
            rows = connection.execute(
                f"SELECT * FROM transactions {where} "
                "ORDER BY transaction_date DESC, id DESC", parameters
            ).fetchall()
        return [self._from_row(row) for row in rows]

    def summary(self, filters: TransactionFilter) -> FinancialSummary:
        transactions = self.list(filters)
        income = sum(t.amount_cents for t in transactions
                     if t.transaction_type == TransactionType.INCOME)
        expense = sum(t.amount_cents for t in transactions
                      if t.transaction_type == TransactionType.EXPENSE)
        return FinancialSummary(income, expense)

    def categories(self) -> list[str]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT DISTINCT category FROM transactions ORDER BY category"
            ).fetchall()
        return [row[0] for row in rows]

