"""Regras de negocio independentes da interface grafica."""
from __future__ import annotations
import csv
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

from app.models import Transaction, TransactionFilter, TransactionType
from app.repository import TransactionRepository


DEFAULT_CATEGORIES = [
    "Alimentacao", "Educacao", "Lazer", "Moradia", "Outros",
    "Salario", "Saude", "Transporte",
]


def parse_money(value: str) -> int:
    normalized = value.strip().replace("R$", "").replace(" ", "")
    if "," in normalized:
        normalized = normalized.replace(".", "").replace(",", ".")
    try:
        amount = Decimal(normalized).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except InvalidOperation as exc:
        raise ValueError("Informe um valor monetario valido.") from exc
    if amount <= 0:
        raise ValueError("O valor deve ser maior que zero.")
    return int(amount * 100)


def format_money(cents: int) -> str:
    value = Decimal(cents) / Decimal(100)
    text = f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {text}"


class FinanceService:
    def __init__(self, repository: TransactionRepository):
        self.repository = repository

    def save(self, description: str, amount: str, transaction_type: str,
             category: str, transaction_date: date, notes: str = "",
             transaction_id: int | None = None) -> int:
        description = description.strip()
        category = category.strip()
        if len(description) < 3:
            raise ValueError("A descricao deve ter pelo menos 3 caracteres.")
        if not category:
            raise ValueError("Selecione ou informe uma categoria.")
        transaction = Transaction(
            id=transaction_id,
            description=description,
            amount_cents=parse_money(amount),
            transaction_type=TransactionType(transaction_type),
            category=category,
            transaction_date=transaction_date,
            notes=notes.strip(),
        )
        if transaction_id is None:
            return self.repository.add(transaction)
        self.repository.update(transaction)
        return transaction_id

    def delete(self, transaction_id: int) -> None:
        self.repository.delete(transaction_id)

    def list(self, filters: TransactionFilter):
        return self.repository.list(filters)

    def summary(self, filters: TransactionFilter):
        return self.repository.summary(filters)

    def categories(self) -> list[str]:
        return sorted(set(DEFAULT_CATEGORIES + self.repository.categories()))

    def export_csv(self, path: Path, filters: TransactionFilter) -> None:
        with path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file, delimiter=";")
            writer.writerow(["Data", "Tipo", "Descricao", "Categoria", "Valor", "Observacoes"])
            for item in self.list(filters):
                writer.writerow([item.transaction_date.strftime("%d/%m/%Y"),
                                 item.transaction_type.value, item.description,
                                 item.category, format_money(item.amount_cents), item.notes])

    def seed_demo(self) -> None:
        if self.repository.list(TransactionFilter()):
            raise ValueError("Os dados de exemplo so podem ser inseridos em um banco vazio.")
        today = date.today()
        examples = [
            ("Salario mensal", "4500,00", "Receita", "Salario", today - timedelta(days=8)),
            ("Freelance de design", "850,00", "Receita", "Outros", today - timedelta(days=3)),
            ("Aluguel", "1450,00", "Despesa", "Moradia", today - timedelta(days=7)),
            ("Supermercado", "486,35", "Despesa", "Alimentacao", today - timedelta(days=2)),
            ("Transporte", "180,00", "Despesa", "Transporte", today),
        ]
        for description, amount, kind, category, day in examples:
            self.save(description, amount, kind, category, day)

