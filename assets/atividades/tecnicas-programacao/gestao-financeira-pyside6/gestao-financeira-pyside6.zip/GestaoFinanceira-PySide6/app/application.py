"""Inicializacao da aplicacao e injecao das dependencias."""
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from app.database import Database
from app.repository import TransactionRepository
from app.services import FinanceService
from app.ui.main_window import MainWindow


def run() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Financas Pessoais")
    app.setStyle("Fusion")

    data_dir = Path(__file__).resolve().parent.parent / "data"
    database = Database(data_dir / "financas.db")
    database.initialize()
    service = FinanceService(TransactionRepository(database))

    window = MainWindow(service)
    window.show()
    return app.exec()

