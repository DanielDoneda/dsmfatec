"""Entidades e objetos de transporte usados pela aplicacao."""
from dataclasses import dataclass
from datetime import date
from enum import Enum


class TransactionType(str, Enum):
    INCOME = "Receita"
    EXPENSE = "Despesa"


@dataclass(frozen=True)
class Transaction:
    description: str
    amount_cents: int
    transaction_type: TransactionType
    category: str
    transaction_date: date
    notes: str = ""
    id: int | None = None


@dataclass(frozen=True)
class TransactionFilter:
    text: str = ""
    transaction_type: TransactionType | None = None
    category: str = ""
    start_date: date | None = None
    end_date: date | None = None


@dataclass(frozen=True)
class FinancialSummary:
    income_cents: int
    expense_cents: int

    @property
    def balance_cents(self) -> int:
        return self.income_cents - self.expense_cents

