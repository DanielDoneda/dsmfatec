APP_STYLE = """
QMainWindow, QDialog { background: #F5F7FB; }
QWidget { font-family: 'Segoe UI'; font-size: 10pt; color: #1F2937; }
QLabel#title { font-size: 22pt; font-weight: 700; color: #132238; }
QFrame#card { background: white; border: 1px solid #E3E8EF; border-radius: 12px; }
QLabel#cardTitle { color: #65758B; font-size: 9pt; font-weight: 600; }
QLabel#cardValue { color: #132238; font-size: 19pt; font-weight: 700; }
QPushButton { background: #2457D6; color: white; border: 0; border-radius: 7px;
              padding: 8px 14px; font-weight: 600; }
QPushButton:hover { background: #1E49B5; }
QPushButton#secondary { background: #E9EEF8; color: #23406F; }
QPushButton#danger { background: #D64545; }
QLineEdit, QComboBox, QDateEdit, QDoubleSpinBox, QTextEdit {
    background: white; border: 1px solid #CBD5E1; border-radius: 6px; padding: 6px;
}
QTableWidget { background: white; border: 1px solid #E3E8EF; border-radius: 8px;
               gridline-color: #EDF1F5; selection-background-color: #DCE7FF; }
QHeaderView::section { background: #EEF2F7; border: 0; border-bottom: 1px solid #DCE3EC;
                       padding: 8px; font-weight: 700; }
"""

