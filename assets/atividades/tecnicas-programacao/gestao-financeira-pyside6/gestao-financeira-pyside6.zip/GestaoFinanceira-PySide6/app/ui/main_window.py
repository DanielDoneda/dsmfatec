"""Janela principal: resumo, filtros, tabela e comandos CRUD."""
from datetime import date
from pathlib import Path

from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QAction, QColor
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDateEdit, QFileDialog,
                               QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QMainWindow, QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from app.models import TransactionFilter, TransactionType
from app.services import FinanceService, format_money
from app.ui.styles import APP_STYLE
from app.ui.transaction_dialog import TransactionDialog


class MainWindow(QMainWindow):
    def __init__(self, service: FinanceService):
        super().__init__()
        self.service = service
        self.transactions = []
        self.setWindowTitle("Financas Pessoais - Gestao Financeira")
        self.resize(1120, 720)
        self.setStyleSheet(APP_STYLE)
        self._build_menu()
        self._build_ui()
        self.refresh()

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("Arquivo")
        export_action = QAction("Exportar tabela para CSV", self)
        export_action.triggered.connect(self.export_csv)
        demo_action = QAction("Inserir dados de demonstracao", self)
        demo_action.triggered.connect(self.seed_demo)
        exit_action = QAction("Sair", self)
        exit_action.triggered.connect(self.close)
        file_menu.addActions([export_action, demo_action, exit_action])

        help_menu = self.menuBar().addMenu("Ajuda")
        about_action = QAction("Sobre", self)
        about_action.triggered.connect(lambda: QMessageBox.about(
            self, "Sobre", "Sistema de Gestao Financeira\nProjeto academico TPII - PySide6 e SQLite"))
        help_menu.addAction(about_action)

    def _build_ui(self) -> None:
        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)
        header = QHBoxLayout()
        title = QLabel("Gestao Financeira")
        title.setObjectName("title")
        add_button = QPushButton("+ Novo lancamento")
        add_button.clicked.connect(self.add_transaction)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(add_button)
        layout.addLayout(header)

        cards = QHBoxLayout()
        self.income_value = self._summary_card(cards, "Receitas")
        self.expense_value = self._summary_card(cards, "Despesas")
        self.balance_value = self._summary_card(cards, "Saldo")
        layout.addLayout(cards)

        filters_frame = QFrame()
        filters_frame.setObjectName("card")
        filters = QGridLayout(filters_frame)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar descricao ou observacao")
        self.type_filter = QComboBox()
        self.type_filter.addItems(["Todos os tipos", "Receita", "Despesa"])
        self.category_filter = QComboBox()
        self.start_date = QDateEdit(QDate.currentDate().addMonths(-1))
        self.end_date = QDateEdit(QDate.currentDate())
        for control in (self.start_date, self.end_date):
            control.setCalendarPopup(True)
            control.setDisplayFormat("dd/MM/yyyy")
        apply_button = QPushButton("Aplicar filtros")
        apply_button.clicked.connect(self.refresh)
        clear_button = QPushButton("Limpar")
        clear_button.setObjectName("secondary")
        clear_button.clicked.connect(self.clear_filters)
        filters.addWidget(QLabel("Busca"), 0, 0)
        filters.addWidget(QLabel("Tipo"), 0, 1)
        filters.addWidget(QLabel("Categoria"), 0, 2)
        filters.addWidget(QLabel("Data inicial"), 0, 3)
        filters.addWidget(QLabel("Data final"), 0, 4)
        filters.addWidget(self.search, 1, 0)
        filters.addWidget(self.type_filter, 1, 1)
        filters.addWidget(self.category_filter, 1, 2)
        filters.addWidget(self.start_date, 1, 3)
        filters.addWidget(self.end_date, 1, 4)
        filters.addWidget(apply_button, 1, 5)
        filters.addWidget(clear_button, 1, 6)
        layout.addWidget(filters_frame)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Data", "Tipo", "Descricao", "Categoria", "Valor", "ID"])
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setColumnHidden(5, True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_transaction)
        layout.addWidget(self.table, 1)

        actions = QHBoxLayout()
        self.count_label = QLabel()
        edit_button = QPushButton("Editar selecionado")
        edit_button.setObjectName("secondary")
        edit_button.clicked.connect(self.edit_transaction)
        delete_button = QPushButton("Excluir selecionado")
        delete_button.setObjectName("danger")
        delete_button.clicked.connect(self.delete_transaction)
        actions.addWidget(self.count_label)
        actions.addStretch()
        actions.addWidget(edit_button)
        actions.addWidget(delete_button)
        layout.addLayout(actions)
        self.setCentralWidget(root)

    @staticmethod
    def _summary_card(layout: QHBoxLayout, title: str) -> QLabel:
        frame = QFrame()
        frame.setObjectName("card")
        box = QVBoxLayout(frame)
        name = QLabel(title)
        name.setObjectName("cardTitle")
        value = QLabel("R$ 0,00")
        value.setObjectName("cardValue")
        box.addWidget(name)
        box.addWidget(value)
        layout.addWidget(frame)
        return value

    def current_filters(self) -> TransactionFilter:
        q_start, q_end = self.start_date.date(), self.end_date.date()
        kind = None if self.type_filter.currentIndex() == 0 else TransactionType(self.type_filter.currentText())
        category = "" if self.category_filter.currentIndex() == 0 else self.category_filter.currentText()
        return TransactionFilter(
            text=self.search.text().strip(), transaction_type=kind, category=category,
            start_date=date(q_start.year(), q_start.month(), q_start.day()),
            end_date=date(q_end.year(), q_end.month(), q_end.day()),
        )

    def refresh(self) -> None:
        if self.start_date.date() > self.end_date.date():
            QMessageBox.warning(self, "Periodo invalido", "A data inicial deve ser anterior a data final.")
            return
        current_category = self.category_filter.currentText()
        self.category_filter.blockSignals(True)
        self.category_filter.clear()
        self.category_filter.addItem("Todas as categorias")
        self.category_filter.addItems(self.service.categories())
        index = self.category_filter.findText(current_category)
        self.category_filter.setCurrentIndex(max(0, index))
        self.category_filter.blockSignals(False)
        filters = self.current_filters()
        self.transactions = self.service.list(filters)
        summary = self.service.summary(filters)
        self.income_value.setText(format_money(summary.income_cents))
        self.expense_value.setText(format_money(summary.expense_cents))
        self.balance_value.setText(format_money(summary.balance_cents))
        self.balance_value.setStyleSheet("color: #16855B" if summary.balance_cents >= 0 else "color: #D64545")
        self.table.setRowCount(len(self.transactions))
        for row, item in enumerate(self.transactions):
            values = [item.transaction_date.strftime("%d/%m/%Y"), item.transaction_type.value,
                      item.description, item.category, format_money(item.amount_cents), str(item.id)]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(value)
                if column == 4:
                    cell.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    cell.setForeground(QColor("#16855B" if item.transaction_type == TransactionType.INCOME else "#D64545"))
                self.table.setItem(row, column, cell)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(2, max(260, self.table.columnWidth(2)))
        self.count_label.setText(f"{len(self.transactions)} lancamento(s) encontrado(s)")

    def clear_filters(self) -> None:
        self.search.clear()
        self.type_filter.setCurrentIndex(0)
        self.category_filter.setCurrentIndex(0)
        self.start_date.setDate(QDate(2000, 1, 1))
        self.end_date.setDate(QDate.currentDate())
        self.refresh()

    def selected_transaction(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Selecione um item", "Selecione um lancamento na tabela.")
            return None
        transaction_id = int(self.table.item(row, 5).text())
        return next((item for item in self.transactions if item.id == transaction_id), None)

    def add_transaction(self) -> None:
        if TransactionDialog(self.service, parent=self).exec():
            self.refresh()

    def edit_transaction(self) -> None:
        item = self.selected_transaction()
        if item and TransactionDialog(self.service, item, self).exec():
            self.refresh()

    def delete_transaction(self) -> None:
        item = self.selected_transaction()
        if not item:
            return
        answer = QMessageBox.question(self, "Confirmar exclusao",
                                      f"Excluir '{item.description}'?",
                                      QMessageBox.Yes | QMessageBox.No)
        if answer == QMessageBox.Yes:
            self.service.delete(item.id)
            self.refresh()

    def export_csv(self) -> None:
        filename, _ = QFileDialog.getSaveFileName(self, "Exportar CSV", "movimentacoes.csv", "CSV (*.csv)")
        if filename:
            self.service.export_csv(Path(filename), self.current_filters())
            QMessageBox.information(self, "Exportacao concluida", "Arquivo CSV criado com sucesso.")

    def seed_demo(self) -> None:
        try:
            self.service.seed_demo()
            self.clear_filters()
        except ValueError as error:
            QMessageBox.information(self, "Dados de demonstracao", str(error))

