"""Formulario modal para inclusao e alteracao de lancamentos."""
from datetime import date

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (QComboBox, QDateEdit, QDialog, QDialogButtonBox,
                               QFormLayout, QLineEdit, QMessageBox, QTextEdit,
                               QVBoxLayout)

from app.models import Transaction
from app.services import FinanceService, format_money


class TransactionDialog(QDialog):
    def __init__(self, service: FinanceService, transaction: Transaction | None = None,
                 parent=None):
        super().__init__(parent)
        self.service = service
        self.transaction = transaction
        self.setWindowTitle("Editar lancamento" if transaction else "Novo lancamento")
        self.setMinimumWidth(430)

        self.description = QLineEdit()
        self.amount = QLineEdit()
        self.amount.setPlaceholderText("Ex.: 125,90")
        self.kind = QComboBox()
        self.kind.addItems(["Receita", "Despesa"])
        self.category = QComboBox()
        self.category.setEditable(True)
        self.category.addItems(service.categories())
        self.transaction_date = QDateEdit(QDate.currentDate())
        self.transaction_date.setCalendarPopup(True)
        self.transaction_date.setDisplayFormat("dd/MM/yyyy")
        self.notes = QTextEdit()
        self.notes.setMaximumHeight(80)

        form = QFormLayout()
        form.addRow("Descricao*", self.description)
        form.addRow("Valor*", self.amount)
        form.addRow("Tipo*", self.kind)
        form.addRow("Categoria*", self.category)
        form.addRow("Data*", self.transaction_date)
        form.addRow("Observacoes", self.notes)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("Salvar")
        buttons.button(QDialogButtonBox.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)
        if transaction:
            self._fill(transaction)

    def _fill(self, item: Transaction) -> None:
        self.description.setText(item.description)
        self.amount.setText(format_money(item.amount_cents).replace("R$ ", ""))
        self.kind.setCurrentText(item.transaction_type.value)
        self.category.setCurrentText(item.category)
        self.transaction_date.setDate(QDate(item.transaction_date.year,
                                             item.transaction_date.month,
                                             item.transaction_date.day))
        self.notes.setPlainText(item.notes)

    def _save(self) -> None:
        selected = self.transaction_date.date()
        try:
            self.service.save(
                self.description.text(), self.amount.text(), self.kind.currentText(),
                self.category.currentText(),
                date(selected.year(), selected.month(), selected.day()),
                self.notes.toPlainText(), self.transaction.id if self.transaction else None,
            )
        except (ValueError, LookupError) as error:
            QMessageBox.warning(self, "Verifique os dados", str(error))
            return
        self.accept()

