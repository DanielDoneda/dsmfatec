"""Aplicacao desktop de gestao financeira."""

