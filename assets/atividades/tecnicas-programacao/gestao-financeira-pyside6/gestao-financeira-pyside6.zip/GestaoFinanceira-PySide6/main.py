"""Ponto de entrada do Sistema de Gestao Financeira."""
from app.application import run


if __name__ == "__main__":
    raise SystemExit(run())

