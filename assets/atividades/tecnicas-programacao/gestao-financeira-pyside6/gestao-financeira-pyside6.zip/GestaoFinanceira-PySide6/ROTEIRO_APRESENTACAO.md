# Roteiro de apresentacao - ate 15 minutos

## 0:00-1:00 - Abertura

Apresentar integrantes, disciplina e objetivo: estudar PySide6 e aplicar a biblioteca em um sistema financeiro funcional.

## 1:00-3:00 - Conceito e origem

- PySide6 conecta Python ao Qt 6 e e mantido pela Qt Company.
- O Qt nasceu para interfaces multiplataforma e possui componentes para janelas, tabelas, formularios e eventos.
- Sinais e slots conectam uma acao do usuario, como um clique, a uma funcao Python.

## 3:00-4:30 - Vantagens e limitacoes

Vantagens: visual profissional, multiplataforma, muitos widgets e boa documentacao. Limitacoes: pacote maior que Tkinter, mais conceitos iniciais e etapa adicional para gerar um executavel independente.

## 4:30-6:00 - Arquitetura

Mostrar a arvore de pastas no PyCharm. Explicar o caminho interface > servico > repositorio > SQLite. Destacar que separar responsabilidades evita SQL dentro da tela e permite testes automatizados.

## 6:00-11:30 - Demonstracao ao vivo

1. Iniciar `main.py` no PyCharm.
2. Se o banco estiver vazio, usar **Arquivo > Inserir dados de demonstracao**.
3. Mostrar os totais e a tabela.
4. Cadastrar uma receita com descricao, valor, categoria e data.
5. Cadastrar uma despesa e observar a alteracao do saldo.
6. Editar um lancamento com duplo clique.
7. Filtrar por tipo, categoria ou periodo.
8. Buscar uma descricao.
9. Exportar a visao filtrada para CSV.
10. Excluir um registro e mostrar a confirmacao.

## 11:30-13:00 - Codigo comentado

Abrir `transaction_dialog.py` para mostrar o evento do botao Salvar. Depois, abrir `services.py` e explicar validacao e conversao do dinheiro para centavos. Por fim, abrir `repository.py` e mostrar o `INSERT` parametrizado.

## 13:00-14:00 - Testes e persistencia

Executar `python -m unittest discover -s tests -v`. Fechar e reabrir o programa para provar que o SQLite preserva os dados.

## 14:00-15:00 - Conclusao

Concluir que PySide6 atende sistemas desktop completos, enquanto SQLite simplifica a persistencia local. Reservar os segundos finais para perguntas.

## Plano de contingencia

- Testar o ambiente e inserir dados antes da aula.
- Levar o projeto em ZIP e uma copia em nuvem.
- Se a demonstracao falhar, apresentar a sequencia pelas telas descritas no roteiro e mostrar os testes.

