import tempfile
import unittest
from datetime import date
from pathlib import Path

from app.database import Database
from app.models import TransactionFilter, TransactionType
from app.repository import TransactionRepository
from app.services import FinanceService, format_money, parse_money


class FinanceServiceTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        database = Database(Path(self.temp.name) / "test.db")
        database.initialize()
        self.service = FinanceService(TransactionRepository(database))

    def tearDown(self):
        self.temp.cleanup()

    def test_money_conversion(self):
        self.assertEqual(parse_money("1.234,56"), 123456)
        self.assertEqual(format_money(123456), "R$ 1.234,56")

    def test_crud_and_summary(self):
        income_id = self.service.save("Salario", "3000,00", "Receita", "Salario", date(2026, 11, 1))
        expense_id = self.service.save("Mercado", "250,50", "Despesa", "Alimentacao", date(2026, 11, 2))
        summary = self.service.summary(TransactionFilter())
        self.assertEqual(summary.income_cents, 300000)
        self.assertEqual(summary.expense_cents, 25050)
        self.service.save("Mercado do mes", "300,00", "Despesa", "Alimentacao", date(2026, 11, 2), transaction_id=expense_id)
        filtered = self.service.list(TransactionFilter(transaction_type=TransactionType.EXPENSE))
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered[0].description, "Mercado do mes")
        self.service.delete(income_id)
        self.assertEqual(len(self.service.list(TransactionFilter())), 1)

    def test_validation(self):
        with self.assertRaises(ValueError):
            self.service.save("ab", "0", "Receita", "Salario", date.today())


if __name__ == "__main__":
    unittest.main()

