package br.com.fatec.loja.micro.produto;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Map;

@RestController
public class ProdutoController {
    private final Map<Long, Produto> produtos = Map.of(
            1L, new Produto(1L, "Teclado mecanico", new BigDecimal("250.00")),
            2L, new Produto(2L, "Mouse sem fio", new BigDecimal("120.00"))
    );

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "service", "produto-service");
    }

    @GetMapping("/produtos/{id}")
    public ResponseEntity<Produto> buscar(@PathVariable Long id) {
        // Este microsservico cuida somente do catalogo de produtos.
        Produto produto = produtos.get(id);
        return produto == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(produto);
    }
}

record Produto(Long id, String nome, BigDecimal preco) {}
