package br.com.fatec.loja.micro.pedido;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.math.BigDecimal;
import java.util.Map;

@RestController
public class PedidoController {
    private final RestClient restClient;
    private final String clienteUrl;
    private final String produtoUrl;
    private final String estoqueUrl;
    private final String pagamentoUrl;

    public PedidoController(
            RestClient restClient,
            @Value("${servicos.cliente.url}") String clienteUrl,
            @Value("${servicos.produto.url}") String produtoUrl,
            @Value("${servicos.estoque.url}") String estoqueUrl,
            @Value("${servicos.pagamento.url}") String pagamentoUrl
    ) {
        this.restClient = restClient;
        this.clienteUrl = clienteUrl;
        this.produtoUrl = produtoUrl;
        this.estoqueUrl = estoqueUrl;
        this.pagamentoUrl = pagamentoUrl;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "service", "pedido-service");
    }

    @PostMapping("/pedidos")
    public ResponseEntity<PedidoResponse> criarPedido(@RequestBody PedidoRequest request) {
        // Em microsservicos, o pedido-service coordena servicos pequenos e independentes.
        Map cliente;
        try {
            cliente = restClient.get()
                    .uri(clienteUrl + "/clientes/" + request.clienteId())
                    .retrieve()
                    .body(Map.class);
        } catch (RestClientException ex) {
            return falhaServico("cliente-service", ex);
        }

        Map produto;
        try {
            produto = restClient.get()
                    .uri(produtoUrl + "/produtos/" + request.produtoId())
                    .retrieve()
                    .body(Map.class);
        } catch (RestClientException ex) {
            return falhaServico("produto-service", ex);
        }

        if (cliente == null || produto == null) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Cliente ou produto nao encontrado", BigDecimal.ZERO));
        }

        Long produtoId = numeroLong(produto.get("id"));
        BigDecimal preco = numeroDecimal(produto.get("preco"));
        BigDecimal total = preco.multiply(BigDecimal.valueOf(request.quantidade()));

        Map reserva;
        try {
            reserva = restClient.post()
                    .uri(estoqueUrl + "/reservas")
                    .body(new ReservaRequest(produtoId, request.quantidade()))
                    .retrieve()
                    .body(Map.class);
        } catch (RestClientException ex) {
            return falhaServico("estoque-service", ex);
        }

        if (reserva == null || !Boolean.TRUE.equals(reserva.get("reservado"))) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Estoque insuficiente", total));
        }

        Map pagamento;
        try {
            // Este pagamento chama um servico feito em Python.
            // A comunicacao continua sendo HTTP/JSON, por isso a linguagem interna nao importa para quem consome.
            pagamento = restClient.post()
                    .uri(pagamentoUrl + "/pagamentos")
                    .body(new PagamentoRequest(total))
                    .retrieve()
                    .body(Map.class);
        } catch (RestClientException ex) {
            return falhaServico("pagamento-service-python", ex);
        }

        if (pagamento == null || !Boolean.TRUE.equals(pagamento.get("aprovado"))) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Pagamento recusado", total));
        }

        return ResponseEntity.ok(new PedidoResponse("CONFIRMADO", "Pedido confirmado por microsservicos", total));
    }

    private Long numeroLong(Object valor) {
        return Long.valueOf(valor.toString());
    }

    private BigDecimal numeroDecimal(Object valor) {
        return new BigDecimal(valor.toString());
    }

    private ResponseEntity<PedidoResponse> falhaServico(String servico, Exception ex) {
        return ResponseEntity.status(503).body(new PedidoResponse(
                "ERRO",
                "Falha ao chamar " + servico + ": " + ex.getMessage(),
                BigDecimal.ZERO
        ));
    }
}

record PedidoRequest(Long clienteId, Long produtoId, Integer quantidade) {}
record PedidoResponse(String status, String mensagem, BigDecimal total) {}
record Cliente(Long id, String nome) {}
record Produto(Long id, String nome, BigDecimal preco) {}
record ReservaRequest(Long produtoId, Integer quantidade) {}
record ReservaResponse(boolean reservado, String mensagem) {}
record PagamentoRequest(BigDecimal valor) {}
record PagamentoResponse(boolean aprovado, String mensagem) {}
