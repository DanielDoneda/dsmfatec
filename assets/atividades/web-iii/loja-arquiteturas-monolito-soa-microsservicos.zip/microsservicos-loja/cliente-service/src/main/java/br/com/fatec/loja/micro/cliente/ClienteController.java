package br.com.fatec.loja.micro.cliente;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ClienteController {
    private final Map<Long, Cliente> clientes = Map.of(
            1L, new Cliente(1L, "Ana Souza"),
            2L, new Cliente(2L, "Carlos Lima")
    );

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "service", "cliente-service");
    }

    @GetMapping("/clientes/{id}")
    public ResponseEntity<Cliente> buscar(@PathVariable Long id) {
        // Este microsservico conhece apenas dados de cliente.
        Cliente cliente = clientes.get(id);
        return cliente == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(cliente);
    }
}

record Cliente(Long id, String nome) {}
