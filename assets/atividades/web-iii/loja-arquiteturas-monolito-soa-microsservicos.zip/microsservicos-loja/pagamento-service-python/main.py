from decimal import Decimal
from http.server import BaseHTTPRequestHandler, HTTPServer
import json


PORTA = 8094


class PagamentoHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _responder_json(self, status_http, dados):
        resposta = json.dumps(dados).encode("utf-8")

        self.send_response(status_http)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(resposta)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(resposta)
        self.close_connection = True

    def do_GET(self):
        # Endpoint simples para verificar se o microsservico esta rodando.
        if self.path == "/health":
            self._responder_json(200, {
                "status": "ok",
                "service": "pagamento-service-python"
            })
            return

        self._responder_json(404, {"mensagem": "Endpoint nao encontrado"})

    def do_POST(self):
        if self.path != "/pagamentos":
            self._responder_json(404, {"mensagem": "Endpoint nao encontrado"})
            return

        corpo = self._ler_corpo_requisicao()

        try:
            dados = json.loads(corpo)
            valor = Decimal(str(dados.get("valor", "0")))
        except Exception:
            self._responder_json(400, {
                "aprovado": False,
                "mensagem": "JSON invalido"
            })
            return

        # Este microsservico foi feito em Python para demonstrar independencia tecnologica.
        # O pedido-service, em Java/Spring Boot, conversa com ele por HTTP/JSON.
        if valor > Decimal("1000.00"):
            self._responder_json(200, {
                "aprovado": False,
                "mensagem": "Pagamento recusado pelo limite da compra"
            })
            return

        self._responder_json(200, {
            "aprovado": True,
            "mensagem": "Pagamento aprovado pelo servico Python"
        })

    def log_message(self, formato, *args):
        # Mantem o terminal mais limpo durante a apresentacao.
        print("[%s] %s" % (self.log_date_time_string(), formato % args))

    def _ler_corpo_requisicao(self):
        # O Spring pode enviar o corpo com Content-Length ou em blocos/chunks.
        # Este metodo aceita os dois formatos para evitar erro na integracao Java -> Python.
        if self.headers.get("Transfer-Encoding", "").lower() == "chunked":
            partes = []
            while True:
                linha_tamanho = self.rfile.readline().strip()
                if not linha_tamanho:
                    continue

                tamanho = int(linha_tamanho.split(b";")[0], 16)
                if tamanho == 0:
                    self.rfile.readline()
                    break

                partes.append(self.rfile.read(tamanho))
                self.rfile.readline()

            return b"".join(partes).decode("utf-8")

        tamanho = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(tamanho).decode("utf-8")


if __name__ == "__main__":
    servidor = HTTPServer(("127.0.0.1", PORTA), PagamentoHandler)
    print(f"pagamento-service-python rodando em http://127.0.0.1:{PORTA}", flush=True)
    print("Endpoints: GET /health, POST /pagamentos", flush=True)
    servidor.serve_forever()
