package br.com.fatec.loja.monolito;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class LojaController {
    private final Map<Long, Cliente> clientes = new HashMap<>();
    private final Map<Long, Produto> produtos = new HashMap<>();
    private final Map<Long, Integer> estoque = new HashMap<>();

    public LojaController() {
        clientes.put(1L, new Cliente(1L, "Ana Souza"));
        clientes.put(2L, new Cliente(2L, "Carlos Lima"));

        produtos.put(1L, new Produto(1L, "Teclado mecanico", new BigDecimal("250.00")));
        produtos.put(2L, new Produto(2L, "Mouse sem fio", new BigDecimal("120.00")));

        estoque.put(1L, 10);
        estoque.put(2L, 15);
    }

    @GetMapping("/clientes")
    public List<Cliente> listarClientes() {
        return clientes.values().stream().toList();
    }

    @GetMapping("/produtos")
    public List<Produto> listarProdutos() {
        return produtos.values().stream().toList();
    }

    @GetMapping("/estoque/{produtoId}")
    public EstoqueResponse consultarEstoque(@PathVariable Long produtoId) {
        return new EstoqueResponse(produtoId, estoque.getOrDefault(produtoId, 0));
    }

    @PostMapping("/pedidos")
    public ResponseEntity<PedidoResponse> criarPedido(@RequestBody PedidoRequest request) {
        // No monolito, o fluxo inteiro acontece dentro da mesma aplicacao.
        Cliente cliente = clientes.get(request.clienteId());
        Produto produto = produtos.get(request.produtoId());

        if (cliente == null || produto == null) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Cliente ou produto nao encontrado", BigDecimal.ZERO));
        }

        int quantidadeAtual = estoque.getOrDefault(produto.id(), 0);
        if (quantidadeAtual < request.quantidade()) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Estoque insuficiente", BigDecimal.ZERO));
        }

        BigDecimal total = produto.preco().multiply(BigDecimal.valueOf(request.quantidade()));
        PagamentoResponse pagamento = processarPagamento(total);

        if (!pagamento.aprovado()) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", pagamento.mensagem(), total));
        }

        estoque.put(produto.id(), quantidadeAtual - request.quantidade());
        return ResponseEntity.ok(new PedidoResponse("CONFIRMADO", "Pedido confirmado para " + cliente.nome(), total));
    }

    private PagamentoResponse processarPagamento(BigDecimal total) {
        // O pagamento tambem esta dentro do mesmo projeto, uma caracteristica comum do monolito.
        if (total.compareTo(new BigDecimal("1000.00")) > 0) {
            return new PagamentoResponse(false, "Pagamento recusado pelo limite da compra");
        }
        return new PagamentoResponse(true, "Pagamento aprovado");
    }
}

record Cliente(Long id, String nome) {}
record Produto(Long id, String nome, BigDecimal preco) {}
record EstoqueResponse(Long produtoId, Integer quantidade) {}
record PedidoRequest(Long clienteId, Long produtoId, Integer quantidade) {}
record PedidoResponse(String status, String mensagem, BigDecimal total) {}
record PagamentoResponse(boolean aprovado, String mensagem) {}

