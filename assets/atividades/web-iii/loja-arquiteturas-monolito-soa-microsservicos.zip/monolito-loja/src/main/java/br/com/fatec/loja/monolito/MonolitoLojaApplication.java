package br.com.fatec.loja.monolito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonolitoLojaApplication {
    public static void main(String[] args) {
        SpringApplication.run(MonolitoLojaApplication.class, args);
    }
}

