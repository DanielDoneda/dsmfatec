# Loja Virtual — Monolito, SOA e Microsserviços

Projeto acadêmico de Desenvolvimento Web III que implementa o mesmo fluxo de uma loja virtual em três arquiteturas. O objetivo é comparar a organização, a comunicação e a distribuição de responsabilidades em uma aplicação monolítica, uma solução SOA e uma solução baseada em microsserviços.

## Tecnologias

- Java 17
- Spring Boot 3.3.5
- Maven 3.9 ou superior
- Python 3 (somente no serviço de pagamento dos microsserviços)
- Postman opcional para executar as requisições prontas

Os dados ficam somente em memória. O projeto não usa banco de dados, senhas, tokens ou serviços externos.

## Execução rápida no Windows

1. Instale Java 17, Maven e Python 3.
2. Confirme no terminal: `java -version`, `mvn -version` e `python --version`.
3. Extraia todo o ZIP para uma pasta.
4. Execute `INICIAR_PROJETO.bat`.
5. Escolha no menu a arquitetura que deseja iniciar.
6. Aguarde a compilação. Na primeira execução, o Maven precisará de internet para baixar as dependências.
7. Importe `FATEC_Loja_Arquiteturas.postman_collection.json` no Postman para testar os endpoints.

Cada serviço abre em uma janela separada. Para encerrá-lo, use `Ctrl + C` na janela correspondente.

## Portas utilizadas

### Monolito

- `8080` — aplicação completa

### SOA

- `8081` — serviço comercial
- `8082` — serviço financeiro
- `8083` — serviço de estoque

### Microsserviços

- `8090` — cliente-service
- `8091` — produto-service
- `8092` — estoque-service
- `8093` — pedido-service
- `8094` — pagamento-service-python

## Execução manual

Para iniciar um serviço Java separadamente, abra o terminal na pasta que contém o `pom.xml` e execute:

```text
mvn spring-boot:run
```

Para iniciar o serviço de pagamento em Python:

```text
cd microsservicos-loja\pagamento-service-python
python main.py
```

Na arquitetura SOA e na arquitetura de microsserviços, todos os serviços da opção escolhida precisam estar em execução para que o fluxo completo de pedido funcione.

## Teste rápido

Depois de iniciar uma arquitetura, use a coleção do Postman incluída no projeto. Ela contém exemplos para listar clientes e produtos, verificar serviços e criar pedidos aprovados ou recusados.
