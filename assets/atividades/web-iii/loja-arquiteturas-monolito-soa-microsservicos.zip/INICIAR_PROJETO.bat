@echo off
setlocal

REM Launcher unico do projeto FATEC.
REM Use este arquivo para iniciar Monolito, SOA ou Microsservicos.

set "RAIZ=%~dp0"
set "MAVEN_LOCAL=%RAIZ%.tools\apache-maven-3.9.16\bin\mvn.cmd"
set "PYTHON_CMD=python"

if exist "%MAVEN_LOCAL%" (
    set "MAVEN=%MAVEN_LOCAL%"
) else (
    set "MAVEN=mvn"
)

python --version >nul 2>&1
if errorlevel 1 (
    py --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py"
)

if "%~1"=="--spring" goto spring
if "%~1"=="--python" goto python

:menu
cls
echo =========================================
echo      Loja Virtual FATEC - Arquiteturas
echo =========================================
echo.
echo 1 - Iniciar Monolito
echo 2 - Iniciar SOA
echo 3 - Iniciar Microsservicos
echo 4 - Verificar estrutura
echo 0 - Sair
echo.
set /p OPCAO=Escolha uma opcao: 

if "%OPCAO%"=="1" goto monolito
if "%OPCAO%"=="2" goto soa
if "%OPCAO%"=="3" goto microsservicos
if "%OPCAO%"=="4" goto verificar
if "%OPCAO%"=="0" exit /b 0

echo.
echo Opcao invalida.
pause
goto menu

:monolito
call :abrir_spring "%RAIZ%monolito-loja" "monolito-loja" "8080"
goto fim_menu

:soa
call :abrir_spring "%RAIZ%soa-loja\financeiro-service" "financeiro-service" "8082"
call :abrir_spring "%RAIZ%soa-loja\estoque-service" "estoque-service" "8083"
call :abrir_spring "%RAIZ%soa-loja\comercial-service" "comercial-service" "8081"
goto fim_menu

:microsservicos
call :abrir_spring "%RAIZ%microsservicos-loja\cliente-service" "cliente-service" "8090"
call :abrir_spring "%RAIZ%microsservicos-loja\produto-service" "produto-service" "8091"
call :abrir_spring "%RAIZ%microsservicos-loja\estoque-service" "estoque-service" "8092"
call :abrir_python "%RAIZ%microsservicos-loja\pagamento-service-python" "pagamento-service-python" "8094"
call :abrir_spring "%RAIZ%microsservicos-loja\pedido-service" "pedido-service" "8093"
goto fim_menu

:verificar
echo.
echo Verificando projeto em:
echo %RAIZ%
echo.

if exist "%MAVEN_LOCAL%" (
    echo OK: Maven local encontrado.
) else (
    echo AVISO: Maven local nao encontrado. Vou tentar usar mvn do Windows.
)

if exist "%RAIZ%monolito-loja\pom.xml" (
    echo OK: pom.xml do monolito encontrado.
) else (
    echo ERRO: pom.xml do monolito nao encontrado.
)

if exist "%RAIZ%monolito-loja\src\main\java\br\com\fatec\loja\monolito\MonolitoLojaApplication.java" (
    echo OK: classe principal do monolito encontrada.
) else (
    echo ERRO: classe principal do monolito nao encontrada.
)

if exist "%RAIZ%FATEC_Loja_Arquiteturas.postman_collection.json" (
    echo OK: colecao do Postman encontrada.
) else (
    echo AVISO: colecao do Postman nao encontrada.
)

echo.
pause
goto menu

:fim_menu
echo.
echo Servico(s) iniciando em janela(s) separada(s).
echo Aguarde finalizar o carregamento e use o Postman.
echo.
pause
goto menu

:abrir_spring
start "%~2 :%~3" "%ComSpec%" /k ""%~f0" --spring "%~1" "%~2" "%~3""
exit /b 0

:abrir_python
start "%~2 :%~3" "%ComSpec%" /k ""%~f0" --python "%~1" "%~2" "%~3""
exit /b 0

:spring
set "PASTA=%~2"
set "NOME=%~3"
set "PORTA=%~4"
echo Iniciando %NOME% na porta %PORTA%...
echo Pasta: %PASTA%
echo.

if not exist "%PASTA%\pom.xml" (
    echo ERRO: pom.xml nao encontrado.
    echo Verifique se a pasta foi copiada completa.
    pause
    exit /b 1
)

call "%MAVEN%" -f "%PASTA%\pom.xml" -DskipTests clean package
if errorlevel 1 (
    echo.
    echo ERRO: falha ao compilar %NOME%.
    pause
    exit /b 1
)

if not exist "%PASTA%\target\*.jar" (
    echo.
    echo ERRO: nenhum arquivo .jar foi gerado em %PASTA%\target.
    pause
    exit /b 1
)

for %%J in ("%PASTA%\target\*.jar") do set "JAR_APP=%%~fJ"

echo.
echo Executando arquivo:
echo %JAR_APP%
echo.

java -jar "%JAR_APP%"
echo.
echo %NOME% foi encerrado.
pause
exit /b 0

:python
set "PASTA=%~2"
set "NOME=%~3"
set "PORTA=%~4"
echo Iniciando %NOME% na porta %PORTA%...
echo Pasta: %PASTA%
echo.

if not exist "%PASTA%\main.py" (
    echo ERRO: main.py nao encontrado.
    echo Verifique se a pasta foi copiada completa.
    pause
    exit /b 1
)

cd /d "%PASTA%"
%PYTHON_CMD% main.py
echo.
echo %NOME% foi encerrado.
pause
exit /b 0
