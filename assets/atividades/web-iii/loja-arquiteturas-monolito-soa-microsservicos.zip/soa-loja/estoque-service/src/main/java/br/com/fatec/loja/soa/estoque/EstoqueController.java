package br.com.fatec.loja.soa.estoque;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class EstoqueController {
    private final Map<Long, Integer> estoque = new HashMap<>();

    public EstoqueController() {
        estoque.put(1L, 10);
        estoque.put(2L, 15);
    }

    @GetMapping("/estoque/{produtoId}")
    public EstoqueResponse consultar(@PathVariable Long produtoId) {
        // Este servico maior concentra regras relacionadas a estoque.
        return new EstoqueResponse(produtoId, estoque.getOrDefault(produtoId, 0));
    }

    @PostMapping("/estoque/reservas")
    public ResponseEntity<ReservaResponse> reservar(@RequestBody ReservaRequest request) {
        int quantidadeAtual = estoque.getOrDefault(request.produtoId(), 0);
        if (quantidadeAtual < request.quantidade()) {
            return ResponseEntity.ok(new ReservaResponse(false, "Estoque insuficiente"));
        }

        estoque.put(request.produtoId(), quantidadeAtual - request.quantidade());
        return ResponseEntity.ok(new ReservaResponse(true, "Estoque reservado"));
    }
}

record EstoqueResponse(Long produtoId, Integer quantidade) {}
record ReservaRequest(Long produtoId, Integer quantidade) {}
record ReservaResponse(boolean reservado, String mensagem) {}
