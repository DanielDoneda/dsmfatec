package br.com.fatec.loja.soa.financeiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceiroServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(FinanceiroServiceApplication.class, args);
    }
}

