package br.com.fatec.loja.soa.financeiro;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class FinanceiroController {
    @PostMapping("/pagamentos")
    public PagamentoResponse processar(@RequestBody PagamentoRequest request) {
        // Na SOA, este servico representa uma area maior: financeiro.
        // Em um sistema real, ele poderia cuidar de pagamento, fatura e nota fiscal.
        if (request.valor().compareTo(new BigDecimal("1000.00")) > 0) {
            return new PagamentoResponse(false, "Pagamento recusado pelo servico financeiro");
        }
        return new PagamentoResponse(true, "Pagamento aprovado pelo servico financeiro");
    }
}

record PagamentoRequest(BigDecimal valor) {}
record PagamentoResponse(boolean aprovado, String mensagem) {}

