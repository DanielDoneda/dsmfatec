package br.com.fatec.loja.soa.comercial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class ComercialServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ComercialServiceApplication.class, args);
    }

    @Bean
    RestClient restClient() {
        return RestClient.create();
    }
}

