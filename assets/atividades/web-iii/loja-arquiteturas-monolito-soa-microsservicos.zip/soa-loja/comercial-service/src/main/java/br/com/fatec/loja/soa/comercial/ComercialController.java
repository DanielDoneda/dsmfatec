package br.com.fatec.loja.soa.comercial;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class ComercialController {
    private final RestClient restClient;
    private final String financeiroUrl;
    private final String estoqueUrl;
    private final Map<Long, Cliente> clientes = new HashMap<>();
    private final Map<Long, Produto> produtos = new HashMap<>();

    public ComercialController(
            RestClient restClient,
            @Value("${servicos.financeiro.url}") String financeiroUrl,
            @Value("${servicos.estoque.url}") String estoqueUrl
    ) {
        this.restClient = restClient;
        this.financeiroUrl = financeiroUrl;
        this.estoqueUrl = estoqueUrl;

        clientes.put(1L, new Cliente(1L, "Ana Souza"));
        clientes.put(2L, new Cliente(2L, "Carlos Lima"));
        produtos.put(1L, new Produto(1L, "Teclado mecanico", new BigDecimal("250.00")));
        produtos.put(2L, new Produto(2L, "Mouse sem fio", new BigDecimal("120.00")));
    }

    @GetMapping("/clientes")
    public List<Cliente> listarClientes() {
        return clientes.values().stream().toList();
    }

    @GetMapping("/produtos")
    public List<Produto> listarProdutos() {
        return produtos.values().stream().toList();
    }

    @PostMapping("/pedidos")
    public ResponseEntity<PedidoResponse> criarPedido(@RequestBody PedidoRequest request) {
        // Na SOA, o servico comercial possui regras maiores de venda
        // e se integra com outros servicos maiores, como estoque e financeiro.
        Cliente cliente = clientes.get(request.clienteId());
        Produto produto = produtos.get(request.produtoId());

        if (cliente == null || produto == null) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Cliente ou produto nao encontrado", BigDecimal.ZERO));
        }

        BigDecimal total = produto.preco().multiply(BigDecimal.valueOf(request.quantidade()));
        ReservaResponse reserva = restClient.post()
                .uri(estoqueUrl + "/estoque/reservas")
                .body(new ReservaRequest(produto.id(), request.quantidade()))
                .retrieve()
                .body(ReservaResponse.class);

        if (reserva == null || !reserva.reservado()) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Estoque insuficiente", total));
        }

        PagamentoResponse pagamento = restClient.post()
                .uri(financeiroUrl + "/pagamentos")
                .body(new PagamentoRequest(total))
                .retrieve()
                .body(PagamentoResponse.class);

        if (pagamento == null || !pagamento.aprovado()) {
            return ResponseEntity.badRequest().body(new PedidoResponse("RECUSADO", "Pagamento recusado", total));
        }

        return ResponseEntity.ok(new PedidoResponse("CONFIRMADO", "Pedido confirmado no servico comercial", total));
    }
}

record Cliente(Long id, String nome) {}
record Produto(Long id, String nome, BigDecimal preco) {}
record PedidoRequest(Long clienteId, Long produtoId, Integer quantidade) {}
record PedidoResponse(String status, String mensagem, BigDecimal total) {}
record ReservaRequest(Long produtoId, Integer quantidade) {}
record ReservaResponse(boolean reservado, String mensagem) {}
record PagamentoRequest(BigDecimal valor) {}
record PagamentoResponse(boolean aprovado, String mensagem) {}

